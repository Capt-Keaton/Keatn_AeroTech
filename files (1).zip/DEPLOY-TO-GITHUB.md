# Putting this online at capt-keaton.github.io

Your CV already lists `capt-keaton.github.io`, so you have a GitHub account. These are the only two files you need: `index.html` and `experience.html`.

## If the repository already exists

1. Go to `github.com/capt-keaton/capt-keaton.github.io`.
2. Click **Add file → Upload files**.
3. Drag in `index.html` and `experience.html`. If an `index.html` is already there, uploading replaces it.
4. Scroll down, click **Commit changes**.
5. Wait 1–2 minutes, then open **https://capt-keaton.github.io** — page 1 loads, and the "Flight log" tab goes to page 2.

## If you need to create it

1. On GitHub click **+ → New repository**.
2. Repository name must be exactly: `capt-keaton.github.io` (your username, then `.github.io`).
3. Set it to **Public**, tick **Add a README file**, click **Create repository**.
4. **Add file → Upload files** → drag in `index.html` and `experience.html` → **Commit changes**.
5. Go to **Settings → Pages**. Under "Build and deployment", Source should be **Deploy from a branch**, Branch **main**, folder **/ (root)**. Save.
6. Give it 2–5 minutes on the first publish, then open **https://capt-keaton.github.io**.

## The link you send recruiters

```
https://capt-keaton.github.io
```

Put that on both CVs where the LinkedIn line is, and in the "Website" field of your LinkedIn profile.

## Making edits later

Open the file on GitHub, click the pencil icon, edit the text, commit. The live site updates within a minute or two. Everything (styles, layout, colours) is inside each HTML file — there is nothing else to install.

## About the photos

The cockpit, engine-cutaway, turbofan-schematic and 747 images load from Wikimedia Commons under free licences, and the photographers are credited in the footer of each page. They will display correctly on GitHub Pages. If you ever want your own photography instead, replace the `src="..."` value in each `<img>` tag with your own image file name after uploading it to the repo.
