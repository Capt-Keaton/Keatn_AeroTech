# Keaton Clarke — Aviation Portfolio

Two-page static portfolio designed for GitHub Pages.

## Pages
- `index.html` — Profile / landing page
- `experience.html` — Detailed experience, credentials, education and contact

## Deploy on GitHub Pages
1. Create a public repository named `capt-keaton.github.io` if you own the `capt-keaton` GitHub account.
2. Upload `index.html`, `experience.html`, `styles.css`, `script.js`, and this README.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main`, `/root`, and save.
5. The portfolio URL will be `https://capt-keaton.github.io/`.

The resume supplied for this project already lists `capt-keaton.github.io` as a portfolio URL.

## Image sources
The site uses remote images from Unsplash and a jet-engine schematic from Wikimedia Commons. The relevant source pages are linked in the project notes supplied with the build. The Wikimedia jet-engine schematic is licensed CC BY-SA; preserve attribution when redistributing that asset.

## Contact
Keatonclarke37@gmail.com · clarkekeaton75@gmail.com
+233 204 148 130 · +233 594 949 743
LinkedIn: https://www.linkedin.com/in/keaton-c-535616161
